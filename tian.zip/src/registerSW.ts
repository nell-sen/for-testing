/**
 * Register service worker (production only) + skip kalau di iframe / preview host.
 * Import file ini dari src/main.tsx setelah render.
 */
export function registerServiceWorker() {
  if (typeof window === "undefined") return;
  if (!("serviceWorker" in navigator)) return;

  // Skip di dev
  if (import.meta.env.DEV) {
    navigator.serviceWorker.getRegistrations?.().then((rs) => rs.forEach((r) => r.unregister()));
    return;
  }

  // Skip kalau di iframe (Lovable preview)
  let inIframe = false;
  try {
    inIframe = window.self !== window.top;
  } catch {
    inIframe = true;
  }
  const isPreviewHost =
    location.hostname.includes("lovableproject.com") ||
    location.hostname.includes("lovable.app");

  if (inIframe || isPreviewHost) {
    navigator.serviceWorker.getRegistrations?.().then((rs) => rs.forEach((r) => r.unregister()));
    return;
  }

  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch((err) => {
      console.warn("[sw] register failed", err);
    });
  });
}
