import { useEffect, useRef } from "react";

/**
 * Trick: YouTube IFrame audio gak otomatis kepegang Media Session di
 * sebagian device (terutama saat tab di-background di Chrome Android).
 * Kita play silent audio loop di tab utama supaya:
 *   1. Browser anggap tab ini "punya audio aktif" -> gak di-throttle agresif
 *   2. Media Session metadata muncul ke lockscreen / notification
 *   3. JS timer (setInterval) tetap jalan walau tab di background
 *
 * Audio: 1 detik silence WAV, di-loop. Volume 0.001 (silent tapi bukan muted,
 * supaya browser anggap audio "aktif").
 */
const SILENT_WAV =
  "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=";

export function useSilentAudioKeeper(active: boolean) {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!audioRef.current) {
      const a = new Audio(SILENT_WAV);
      a.loop = true;
      a.volume = 0.001;
      a.preload = "auto";
      (a as HTMLAudioElement & { playsInline?: boolean }).playsInline = true;
      audioRef.current = a;
    }
    const a = audioRef.current;
    if (active) {
      a.play().catch(() => {
        /* needs user gesture; akan retry di interaksi berikutnya */
      });
    } else {
      a.pause();
    }
    return () => {
      a.pause();
    };
  }, [active]);
}
