import { useEffect } from "react";

export interface MediaSessionTrack {
  title: string;
  artist?: string;
  album?: string;
  artwork?: string;
}

export interface MediaSessionHandlers {
  onPlay?: () => void;
  onPause?: () => void;
  onNext?: () => void;
  onPrev?: () => void;
  onSeekTo?: (time: number) => void;
  onSeekBackward?: (offset: number) => void;
  onSeekForward?: (offset: number) => void;
}

/**
 * Sync metadata + transport handlers ke OS notification / lockscreen.
 * Bekerja di Chrome Android (lockscreen + notif), Chrome desktop (media hub),
 * dan PWA installed. iOS Safari support terbatas.
 */
export function useMediaSession(
  track: MediaSessionTrack | null,
  isPlaying: boolean,
  handlers: MediaSessionHandlers,
  position?: { duration: number; currentTime: number; playbackRate?: number }
) {
  // Metadata
  useEffect(() => {
    if (!("mediaSession" in navigator)) return;
    if (!track) {
      navigator.mediaSession.metadata = null;
      return;
    }
    const artwork = track.artwork
      ? [
          { src: track.artwork, sizes: "96x96", type: "image/jpeg" },
          { src: track.artwork, sizes: "192x192", type: "image/jpeg" },
          { src: track.artwork, sizes: "512x512", type: "image/jpeg" },
        ]
      : [];
    navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title,
      artist: track.artist || "Glasswave",
      album: track.album || "",
      artwork,
    });
  }, [track?.title, track?.artist, track?.album, track?.artwork]);

  // Playback state
  useEffect(() => {
    if (!("mediaSession" in navigator)) return;
    navigator.mediaSession.playbackState = isPlaying ? "playing" : "paused";
  }, [isPlaying]);

  // Action handlers
  useEffect(() => {
    if (!("mediaSession" in navigator)) return;
    const ms = navigator.mediaSession;
    const set = (action: MediaSessionAction, fn?: (d: MediaSessionActionDetails) => void) => {
      try {
        ms.setActionHandler(action, fn ? (d) => fn(d) : null);
      } catch {
        /* unsupported action */
      }
    };
    set("play", handlers.onPlay && (() => handlers.onPlay!()));
    set("pause", handlers.onPause && (() => handlers.onPause!()));
    set("nexttrack", handlers.onNext && (() => handlers.onNext!()));
    set("previoustrack", handlers.onPrev && (() => handlers.onPrev!()));
    set(
      "seekto",
      handlers.onSeekTo &&
        ((d) => {
          if (typeof d.seekTime === "number") handlers.onSeekTo!(d.seekTime);
        })
    );
    set(
      "seekbackward",
      handlers.onSeekBackward && ((d) => handlers.onSeekBackward!(d.seekOffset || 10))
    );
    set(
      "seekforward",
      handlers.onSeekForward && ((d) => handlers.onSeekForward!(d.seekOffset || 10))
    );
    return () => {
      ["play", "pause", "nexttrack", "previoustrack", "seekto", "seekbackward", "seekforward"].forEach(
        (a) => set(a as MediaSessionAction)
      );
    };
  }, [handlers.onPlay, handlers.onPause, handlers.onNext, handlers.onPrev, handlers.onSeekTo, handlers.onSeekBackward, handlers.onSeekForward]);

  // Position state (progress bar di notif)
  useEffect(() => {
    if (!("mediaSession" in navigator)) return;
    if (!position || !position.duration || !isFinite(position.duration)) return;
    try {
      navigator.mediaSession.setPositionState({
        duration: position.duration,
        playbackRate: position.playbackRate || 1,
        position: Math.min(position.currentTime, position.duration),
      });
    } catch {
      /* ignore */
    }
  }, [position?.duration, position?.currentTime, position?.playbackRate]);
}
