/* eslint-disable no-restricted-globals */
/**
 * Glasswave service worker — minimal, hanya untuk:
 *  - Installability (PWA criteria)
 *  - App shell offline fallback ringan
 * TIDAK cache YouTube / Google API supaya playback selalu fresh.
 */
const VERSION = "v1";
const SHELL_CACHE = `glasswave-shell-${VERSION}`;
const SHELL_ASSETS = ["/", "/index.html", "/manifest.webmanifest"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((c) => c.addAll(SHELL_ASSETS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== SHELL_CACHE).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  // Bypass: API, YouTube, Firebase, analytics — selalu network
  if (
    url.hostname.includes("googleapis.com") ||
    url.hostname.includes("youtube.com") ||
    url.hostname.includes("ytimg.com") ||
    url.hostname.includes("firebaseio.com") ||
    url.hostname.includes("firebase") ||
    url.hostname.includes("gstatic.com")
  ) {
    return;
  }

  // Navigation: network-first, fallback ke cached shell
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req).catch(() => caches.match("/index.html").then((r) => r || Response.error()))
    );
    return;
  }

  // Static assets: stale-while-revalidate
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const fetchPromise = fetch(req)
          .then((res) => {
            if (res && res.status === 200 && res.type === "basic") {
              const clone = res.clone();
              caches.open(SHELL_CACHE).then((c) => c.put(req, clone));
            }
            return res;
          })
          .catch(() => cached);
        return cached || fetchPromise;
      })
    );
  }
});
