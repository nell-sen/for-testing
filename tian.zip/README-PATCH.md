# Glasswave — PWA + Media Session Patch

Patch ini menambahkan:
1. **PWA installable** (manifest + service worker) — user bisa "Add to Home Screen"
2. **Media Session API** — kontrol play/pause/next/prev di **notif & lockscreen**
3. **Silent audio keeper** — supaya tab gak di-throttle Chrome saat background, lagu lanjut jalan walau tab di background / layar HP mati / browser di-minimize

> ⚠️ **Catatan**: Web TIDAK BISA jalan kalau Chrome di-**close total** (swipe kill).
> Itu limitasi platform, cuma native app (Capacitor) yang bisa.
> Tapi **minimize / lock screen / pindah tab → tetap jalan**.

---

## Cara apply ke project lo

Anggap project lo di folder `glasswave-music-player-v2/`.

### 1. Copy file dari patch

```
patch/public/manifest.webmanifest   →  public/manifest.webmanifest
patch/public/sw.js                   →  public/sw.js
patch/src/hooks/useMediaSession.ts   →  src/hooks/useMediaSession.ts
patch/src/hooks/useSilentAudioKeeper.ts → src/hooks/useSilentAudioKeeper.ts
patch/src/registerSW.ts              →  src/registerSW.ts
```

### 2. Bikin 2 icon PWA (wajib)

Taruh di `public/icons/`:
- `icon-192.png` — 192×192
- `icon-512.png` — 512×512

(Bisa pakai logo Glasswave lo, export PNG ukuran segitu. Kalau gak ada, generate cepat di https://realfavicongenerator.net/)

### 3. Update `index.html`

Tambah di dalam `<head>`:

```html
<link rel="manifest" href="/manifest.webmanifest" />
<meta name="theme-color" content="#0b0b0f" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
<meta name="apple-mobile-web-app-title" content="Glasswave" />
<link rel="apple-touch-icon" href="/icons/icon-192.png" />
```

### 4. Update `src/main.tsx`

Tambah di paling bawah file (setelah render):

```ts
import { registerServiceWorker } from "./registerSW";
registerServiceWorker();
```

### 5. Integrasi ke playback engine

Di komponen tempat lo kelola state pemutaran (biasanya `YouTubePlaybackEngine.tsx`
atau player context global), tambah:

```tsx
import { useMediaSession } from "@/hooks/useMediaSession";
import { useSilentAudioKeeper } from "@/hooks/useSilentAudioKeeper";

// di dalam komponen player:
useSilentAudioKeeper(isPlaying); // keep-alive saat lagu jalan

useMediaSession(
  currentTrack
    ? {
        title: currentTrack.title,
        artist: currentTrack.channelTitle,
        artwork: currentTrack.thumbnail, // URL https
      }
    : null,
  isPlaying,
  {
    onPlay: () => play(),
    onPause: () => pause(),
    onNext: () => next(),
    onPrev: () => prev(),
    onSeekTo: (t) => seek(t),
    onSeekBackward: (o) => seek(Math.max(0, currentTime - o)),
    onSeekForward: (o) => seek(Math.min(duration, currentTime + o)),
  },
  { duration, currentTime }
);
```

Sesuaikan nama variabel/fungsi dengan punya lo.

### 6. Build & deploy

```bash
npm run build
# push ke github → vercel auto-deploy
```

---

## Cara test

1. Buka di **HP Android via Chrome**, login HTTPS (Vercel udah HTTPS).
2. Putar lagu → liat notif turun dari atas → harus ada **judul + thumbnail + tombol play/pause/next/prev**.
3. Kunci layar → lagu lanjut, kontrol muncul di lockscreen.
4. Pindah tab / minimize Chrome → lagu tetap jalan.
5. Menu Chrome → **"Install app"** / **"Add to Home Screen"** → bakal muncul icon di home screen, buka dari sana berasa kayak app.

### Kalau ada bug

Lapor ke gue: halaman apa, aksi apa, error apa kalau ada. Gue bisa baca console + network logs dari preview lo langsung — gak perlu screenshot.
